#include <iostream>
#include <dlfcn.h>
#include <stdio.h>

using namespace std;

#define PATH_LIB "./libTestSharedLib.so.1.0.0"
#define FUNC_NAME "_Z11MyStartFuncv"

using libt = void();

void *HANDLE = 0;

libt* loadLib() {
    HANDLE = dlopen(PATH_LIB, RTLD_LAZY);
    cout << HANDLE << '\n';
    libt *func_ptr = (libt*)dlsym(HANDLE, FUNC_NAME);
    cout << func_ptr << '\n';
    return func_ptr;
}

void unloadLib() {
    dlclose(HANDLE);
}

int main()
{
    for (int i = 0; i < 10; ++i) {
        cout << "~~~~~~~~~~~~~~~~~~~~~~\n";
        libt *fun = loadLib();
        if (fun) {
            fun();
        }

        cout << fun;
        unloadLib();
    }

    return 0;
}
