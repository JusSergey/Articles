#ifndef TESTSHAREDLIB_H
#define TESTSHAREDLIB_H

//#include "testsharedlib_global.h"

class /*TESTSHAREDLIBSHARED_EXPORT*/ TestSharedLib
{

public:
    TestSharedLib();
};

#include <iostream>

void MyStartFunc() {
    std::cout << "Was called MyStartFunc" << std::endl;
}

void start() __attribute__ ((constructor));
void finish() __attribute__ ((destructor));

void start()
{ std::cout << "START..." << std::endl; }

void finish()
{ std::cout << "FINISH..." << std::endl; }

#endif // TESTSHAREDLIB_H
